
import streamlit as st
import requests
from datetime import datetime, timedelta

st.set_page_config(page_title="Wettanalyse App", layout="wide", initial_sidebar_state="collapsed")

API_KEY = "8ba7e5d18a5b48409f92838f7adb69b0"
HEADERS = {"X-Auth-Token": API_KEY}
BASE_URL = "https://api.football-data.org/v4"

def fetch_matches():
    today = datetime.today()
    end = today + timedelta(days=3)
    url = f"{BASE_URL}/matches?dateFrom={today.date()}&dateTo={end.date()}"
    r = requests.get(url, headers=HEADERS)
    return r.json().get("matches", []) if r.status_code == 200 else []

def analyze_match(match):
    home = match["homeTeam"]["name"]
    away = match["awayTeam"]["name"]
    utc_date = match["utcDate"]
    date_obj = datetime.strptime(utc_date, "%Y-%m-%dT%H:%M:%SZ")
    day = date_obj.strftime("%A, %d.%m.%Y %H:%M")

    st.markdown(f"### {home} vs. {away}  
🕒 {day}")

    # Dummy stats (to be replaced with real data or models)
    st.write("**1X2 Wahrscheinlichkeit:**")
    st.write("🏠 Heimsieg: 45%  | 🤝 Remis: 30% | 🛫 Auswärtssieg: 25%")
    st.write("**Over/Under 2.5 Tore:** Over 62%")
    st.write("**Beide Teams treffen (BTTS):** 54%")
    st.info("💡 Empfehlung: Tipp 1 oder Over 2.5")
    st.markdown("---")

matches = fetch_matches()

if matches:
    for match in matches:
        analyze_match(match)
else:
    st.warning("Keine Spiele gefunden oder API-Limit erreicht.")
